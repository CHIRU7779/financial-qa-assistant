# Financial Document Q&A Assistant

## Purpose
A Streamlit app that extracts information from financial PDFs and Excel files and answers user queries using a local Ollama model.

## Requirements
- Python 3.9+
- Local Ollama server installed and running

## Setup
```bash
pip install -r requirements.txt
```

## Run Ollama
```bash
ollama serve
ollama run llama3.2
```

## Run the App
```bash
streamlit run app.py
```

Open the local URL (usually http://localhost:8501).

## Notes
- Basic demo extraction only; advanced parsing may require Camelot/Tabula.
- Ensure Ollama is installed and model is available.
