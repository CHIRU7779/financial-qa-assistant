# utils.py
import pandas as pd

def summarize_tables(tables, max_tables=3):
    snippets = []
    for i, t in enumerate(tables[:max_tables]):
        if isinstance(t, pd.DataFrame):
            preview = t.fillna("").head(5)
            snippets.append(f"Table {i+1}:\n" + preview.to_string(index=False))
        else:
            snippets.append(str(t)[:1000])
    return "\n\n".join(snippets)

def find_numeric_in_tables(tables, key_words):
    matches = []
    kws = [k.lower() for k in key_words]
    for ti, t in enumerate(tables):
        if not isinstance(t, pd.DataFrame):
            continue
        t2 = t.astype(str).applymap(lambda x: x.strip())
        for r_idx, row in t2.iterrows():
            row_text = " ".join(row.values.tolist()).lower()
            if any(k in row_text for k in kws):
                for c in t2.columns:
                    val = t2.at[r_idx, c]
                    if any(ch.isdigit() for ch in val):
                        matches.append((ti, r_idx, str(c), val))
    return matches