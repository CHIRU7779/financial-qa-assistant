# ollama_client.py
import requests

OLLAMA_URL = "http://localhost:11434"

class OllamaClient:
    def __init__(self, model: str = "llama3.2:latest", base_url: str = OLLAMA_URL):
        self.base_url = base_url.rstrip('/')
        self.model = model

    def chat(self, messages, stream=False, timeout=60):
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": stream,
        }
        url = f"{self.base_url}/api/chat"
        resp = requests.post(url, json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json()

    def generate(self, prompt: str, stream=False, timeout=60):
        payload = {"model": self.model, "prompt": prompt, "stream": stream}
        url = f"{self.base_url}/api/generate"
        resp = requests.post(url, json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json()