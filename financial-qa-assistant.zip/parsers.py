# parsers.py
import pdfplumber
import pandas as pd
from typing import List, Tuple

def extract_from_pdf(path: str) -> Tuple[str, List[pd.DataFrame]]:
    text_parts = []
    tables = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            try:
                text_parts.append(page.extract_text() or "")
            except Exception:
                pass
            page_tables = page.extract_tables()
            for t in page_tables:
                try:
                    df = pd.DataFrame(t)
                    df.replace("", pd.NA, inplace=True)
                    df.dropna(axis=0, how='all', inplace=True)
                    df.dropna(axis=1, how='all', inplace=True)
                    if not df.empty:
                        tables.append(df)
                except Exception:
                    continue
    full_text = "\n".join(text_parts)
    return full_text, tables

def extract_from_excel(path: str) -> Tuple[str, List[pd.DataFrame]]:
    xls = pd.ExcelFile(path)
    tables = []
    text_parts = []
    for sheet in xls.sheet_names:
        df = xls.parse(sheet)
        tables.append(df)
        small_preview = df.head(10).to_string()
        text_parts.append(f"Sheet: {sheet}\n{small_preview}")
    return "\n".join(text_parts), tables