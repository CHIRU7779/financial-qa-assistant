# app.py
import streamlit as st
from parsers import extract_from_pdf, extract_from_excel
from utils import summarize_tables, find_numeric_in_tables
from ollama_client import OllamaClient
import tempfile

st.set_page_config(page_title="Financial Document Q&A", layout='wide')

st.title("Financial Document Q&A Assistant")

ollama = OllamaClient(model="llama3.2:latest")

uploaded = st.file_uploader("Upload a PDF or Excel financial document", type=["pdf","xlsx","xls"], accept_multiple_files=False)

if uploaded is not None:
    with st.spinner("Processing document..."):
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.'+uploaded.type.split('/')[-1])
        tmp.write(uploaded.getbuffer())
        tmp.flush()
        path = tmp.name

        if uploaded.type == "application/pdf" or uploaded.name.lower().endswith('.pdf'):
            text, tables = extract_from_pdf(path)
        else:
            text, tables = extract_from_excel(path)

        st.success("Document processed")

        st.subheader("Extracted text (truncated)")
        st.code(text[:2500])

        st.subheader("Top table previews")
        for i, t in enumerate(tables[:3]):
            st.write(f"Table {i+1}")
            st.dataframe(t)

        context = text + "\n\n" + summarize_tables(tables)

        st.session_state.setdefault('chat_history', [])
        if 'doc_context' not in st.session_state:
            st.session_state['doc_context'] = context

        st.markdown("---")
        st.header("Ask a question about the document")
        question = st.text_input("Enter a question (for example: 'What was revenue in 2024?')")
        if st.button("Ask") and question.strip():
            st.session_state.chat_history.append({"role": "user", "content": question})

            local_matches = find_numeric_in_tables(tables, ["revenue","sales","net income","profit","total assets","cash flow","expenses"]) 
            local_answer = None
            if local_matches:
                for m in local_matches:
                    if any(k in question.lower() for k in ["revenue","sales","profit","net income"]):
                        local_answer = f"Found possible table match: {m[3]} (table {m[0]+1}, row {m[1]}, column {m[2]})"
                        break

            if local_answer:
                st.info(local_answer)

            messages = [
                {"role": "system", "content": "You are a helpful assistant that answers questions strictly from the provided financial document context. If the information is not present, say you do not have enough information."},
                {"role": "system", "content": f"Document context:\n{st.session_state['doc_context'][:4000]}"},
                {"role": "user", "content": question}
            ]

            try:
                with st.spinner("Querying local model..."):
                    resp = ollama.chat(messages, stream=False)
                answer_text = None
                if isinstance(resp, dict):
                    if 'choices' in resp and len(resp['choices'])>0:
                        c = resp['choices'][0]
                        if isinstance(c, dict) and 'message' in c and isinstance(c['message'], dict):
                            answer_text = c['message'].get('content')
                    if not answer_text and 'text' in resp:
                        answer_text = resp['text']
                if not answer_text:
                    answer_text = str(resp)

                st.session_state.chat_history.append({"role": "assistant", "content": answer_text})
                st.markdown("**Answer:**")
                st.write(answer_text)

            except Exception as e:
                st.error(f"Failed to query Ollama: {e}")

        st.markdown("---")
        st.subheader("Conversation")
        for m in st.session_state['chat_history'][-10:]:
            if m['role'] == 'user':
                st.write(f"**User:** {m['content']}")
            else:
                st.write(f"**Assistant:** {m['content']}")